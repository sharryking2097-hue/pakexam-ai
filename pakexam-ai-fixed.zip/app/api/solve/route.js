import { NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";

// Allowed media types supported by Anthropic API
const ALLOWED_MEDIA_TYPES = [
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
];

// FIX 2 — Simple in-memory rate limit: 10 requests / minute per IP.
// (Public deploy par koi bhi tumhari API key ka bill na bana sake.)
// Note: serverless / multi-instance deploy par iski jagah Upstash Redis
// jaisa shared store use karein.
const RATE_LIMIT = 10;
const WINDOW_MS = 60 * 1000;
const hits = new Map();

function isRateLimited(ip) {
  const now = Date.now();
  const entry = hits.get(ip);
  if (!entry || now - entry.start > WINDOW_MS) {
    hits.set(ip, { start: now, count: 1 });
    return false;
  }
  entry.count += 1;
  return entry.count > RATE_LIMIT;
}

// FIX 3 — Image size cap: 4MB (Anthropic ki 5MB limit se neeche).
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;

export async function POST(request) {
  try {
    // FIX 1 — API key check sab se pehle, client banane se pehle.
    // Pehle client module level par banta tha aur missing key par SDK ka
    // auth error (jis mein .status nahi hota) generic 500 mein gir jata tha.
    if (!process.env.ANTHROPIC_API_KEY) {
      return NextResponse.json(
        { error: "API key invalid hai. Environment variable check karein." },
        { status: 401 }
      );
    }

    // Rate limit check
    const forwarded = request.headers.get("x-forwarded-for");
    const ip = forwarded ? forwarded.split(",")[0].trim() : "unknown";
    if (isRateLimited(ip)) {
      return NextResponse.json(
        { error: "Bohot zyada requests! Thori der baad try karein." },
        { status: 429 }
      );
    }

    // Client ab key check ke baad banta hai, taake missing key par
    // module load / request crash na ho.
    const client = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });

    // Safely parse JSON body
    const body = await request.json().catch(() => ({}));
    const { question, imageBase64 } = body;

    if (!question && !imageBase64) {
      return NextResponse.json(
        { error: "Please type a question or upload an image." },
        { status: 400 }
      );
    }

    const content = [];

    // Base64 & Media Type Validation
    if (imageBase64) {
      let base64Data = imageBase64;
      let mediaType = "image/jpeg"; // Default fallback

      if (imageBase64.includes(",")) {
        const parts = imageBase64.split(",");
        const header = parts[0];
        base64Data = parts[1];

        const match = header.match(/:(.*?);/);
        if (match && match[1]) {
          mediaType = match[1].toLowerCase();
        }
      }

      // Clean base64 string (remove accidental whitespace/newlines)
      base64Data = base64Data.replace(/\s/g, "");

      // FIX 3 — Image size check (base64 se approx bytes nikaal kar).
      // Bari photo Anthropic ki limit se takrane se pehle hi rok di jati hai.
      const approxBytes = Math.floor((base64Data.length * 3) / 4);
      if (approxBytes > MAX_IMAGE_BYTES) {
        return NextResponse.json(
          { error: "Image bohot bari hai. 4MB se chhoti image upload karein." },
          { status: 413 }
        );
      }

      // Ensure media type is explicitly allowed by Claude API
      if (!ALLOWED_MEDIA_TYPES.includes(mediaType)) {
        mediaType = "image/jpeg";
      }

      content.push({
        type: "image",
        source: {
          type: "base64",
          media_type: mediaType,
          data: base64Data,
        },
      });
    }

    const textPrompt = question
      ? `You are a Pakistani BISE Board exam expert. Solve this question step by step.
- For numerical problems: show every step clearly with formulas
- For theory questions: give a complete but concise answer
- Use simple English. If the question is in Urdu, answer in Urdu.
- At the end, write the final answer clearly.

Question: ${question}`
      : `You are a Pakistani BISE Board exam expert. Look at this exam question image and solve it step by step.
- For numerical problems: show every step clearly with formulas
- For theory questions: give a complete but concise answer  
- Use simple English. If the question is in Urdu, answer in Urdu.
- At the end, write the final answer clearly.`;

    content.push({ type: "text", text: textPrompt });

    // Call Anthropic API
    const response = await client.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 1500,
      messages: [{ role: "user", content }],
    });

    // Safely find and extract the text block
    const textBlock = response.content.find((block) => block.type === "text");
    const solution = textBlock ? textBlock.text : "";

    if (!solution) {
      return NextResponse.json(
        { error: "Koi jawab generate nahi ho saka. Dobara try karein." },
        { status: 500 }
      );
    }

    return NextResponse.json({ solution });

  } catch (error) {
    console.error("API Error:", error);

    // Handle specific API errors
    if (error?.status === 401) {
      return NextResponse.json(
        { error: "API key invalid hai. Environment variable check karein." },
        { status: 401 }
      );
    }

    // FIX 1 (backup) — SDK ka auth error .status nahi rakhta, is liye
    // message se bhi pehchano taake missing/invalid key par hamesha
    // sahi message aaye.
    if (
      error?.message &&
      /auth|api key|api-key|credential/i.test(error.message)
    ) {
      return NextResponse.json(
        { error: "API key invalid hai. Environment variable check karein." },
        { status: 401 }
      );
    }

    if (error?.status === 400) {
      return NextResponse.json(
        { error: "Invalid request or image format not supported by Claude." },
        { status: 400 }
      );
    }

    if (error?.status === 429) {
      return NextResponse.json(
        { error: "Bohot zyada requests! Thori der baad try karein." },
        { status: 429 }
      );
    }

    return NextResponse.json(
      { error: "Jawab nahi mila. Dobara try karein." },
      { status: 500 }
    );
  }
}
